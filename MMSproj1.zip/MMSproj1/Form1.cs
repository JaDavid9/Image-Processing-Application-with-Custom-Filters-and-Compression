﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MMSproj1
{
    public partial class Form1 : Form
    {
        private Bitmap originalImage;
        private Bitmap downsampledImage;
        private object original;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                originalImage = new Bitmap(ofd.FileName);
                pictureBox1.Image = originalImage;
            }
        }

        private void btnDownsample_Click(object sender, EventArgs e)
        {
            if (originalImage != null)
            {
                downsampledImage = Downsample(originalImage, 2);
                pictureBox1.Image = downsampledImage;
            }
        }
        private Bitmap Downsample(Bitmap image, int factor)
        {
            int width = image.Width / factor;
            int height = image.Height / factor;
            Bitmap downsampled = new Bitmap(width, height);

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color avgColor = GetAverageColor(image, x * factor, y * factor, factor);
                    downsampled.SetPixel(x, y, avgColor);
                }
            }

            return downsampled;
        }
        private Color GetAverageColor(Bitmap image, int startX, int startY, int factor)
        {
            int r = 0, g = 0, b = 0;
            int count = 0;

            for (int y = startY; y < startY + factor; y++)
            {
                for (int x = startX; x < startX + factor; x++)
                {
                    Color pixelColor = image.GetPixel(x, y);
                    r += pixelColor.R;
                    g += pixelColor.G;
                    b += pixelColor.B;
                    count++;
                }
            }

            return Color.FromArgb(r / count, g / count, b / count);
        }

        private void btnCompress_Click(object sender, EventArgs e)
        {
            if (downsampledImage != null)
            {
                byte[] compressedData = CompressImage(downsampledImage);
                File.WriteAllBytes("compressedImage.cimg", compressedData);
                MessageBox.Show("Image compressed and saved successfully.");
            }
            else
            {
                MessageBox.Show("Please downsample the image first.");
            }
        }
        private byte[] CompressImage(Bitmap image)
        {
            MemoryStream ms = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(ms);

            writer.Write(image.Width);
            writer.Write(image.Height);

            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color pixel = image.GetPixel(x, y);
                    writer.Write(pixel.R);
                    writer.Write(pixel.G);
                    writer.Write(pixel.B);
                }
            }

            writer.Close();
            return ms.ToArray();
        }
        private Bitmap DecompressImage(byte[] data)
        {
            MemoryStream ms = new MemoryStream(data);
            BinaryReader reader = new BinaryReader(ms);

            int width = reader.ReadInt32();
            int height = reader.ReadInt32();
            Bitmap image = new Bitmap(width, height);

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    byte r = reader.ReadByte();
                    byte g = reader.ReadByte();
                    byte b = reader.ReadByte();
                    image.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }

            reader.Close();
            return image;
        }

        private void btnBurkesDither_Click(object sender, EventArgs e)
        {
            if (originalImage != null)
            {
                Bitmap ditheredImage = ApplyBurkesDithering(originalImage);
                pictureBox1.Image = ditheredImage;
            }
            else
            {
                MessageBox.Show("Please load an image first.");
            }
        }
        private Bitmap ApplyBurkesDithering(Bitmap original)
        {
            Bitmap dithered = new Bitmap(original.Width, original.Height);

            int[,] quantError = new int[original.Width, original.Height];

            for (int y = 0; y < original.Height; y++)
            {
                for (int x = 0; x < original.Width; x++)
                {
                    Color oldColor = original.GetPixel(x, y);
                    int gray = (oldColor.R + oldColor.G + oldColor.B) / 3;
                    int newColor = (gray > 128) ? 255 : 0;
                    int error = gray - newColor;

                    dithered.SetPixel(x, y, Color.FromArgb(newColor, newColor, newColor));

                    if (x + 1 < original.Width)
                        quantError[x + 1, y] += (error * 8) / 32;
                    if (x + 2 < original.Width)
                        quantError[x + 2, y] += (error * 4) / 32;
                    if (x - 2 >= 0 && y + 1 < original.Height)
                        quantError[x - 2, y + 1] += (error * 2) / 32;
                    if (x - 1 >= 0 && y + 1 < original.Height)
                        quantError[x - 1, y + 1] += (error * 4) / 32;
                    if (y + 1 < original.Height)
                        quantError[x, y + 1] += (error * 8) / 32;
                    if (x + 1 < original.Width && y + 1 < original.Height)
                        quantError[x + 1, y + 1] += (error * 4) / 32;
                    if (x + 2 < original.Width && y + 1 < original.Height)
                        quantError[x + 2, y + 1] += (error * 2) / 32;
                }
            }

            return dithered;
        }

        private void btnInvertFilter_Click(object sender, EventArgs e)
        {
            if (originalImage != null)
            {
                Bitmap invertedImage = ApplyInvertFilter(originalImage);
                pictureBox1.Image = invertedImage;
            }
            else
            {
                MessageBox.Show("Please load an image first.");
            }
        }
        private Bitmap ApplyInvertFilter(Bitmap original)
        {
            Bitmap inverted = new Bitmap(original.Width, original.Height);

            for (int y = 0; y < original.Height; y++)
            {
                for (int x = 0; x < original.Width; x++)
                {
                    Color pixelColor = original.GetPixel(x, y);
                    Color invertedColor = Color.FromArgb(255 - pixelColor.R, 255 - pixelColor.G, 255 - pixelColor.B);
                    inverted.SetPixel(x, y, invertedColor);
                }
            }

            return inverted;
        }

        private void btnKuwaharaFilter1_Click(object sender, EventArgs e)
        {
            if (originalImage != null)
            {
                int radius = 5; // Prilagodite vrednost radijusa po potrebi
                Bitmap kuwaharaImage = ApplyKuwaharaFilter(originalImage, radius);
                pictureBox1.Image = kuwaharaImage;
            }
            else
            {
                MessageBox.Show("Please load an image first.");
            }
        }
        private Bitmap ApplyKuwaharaFilter(Bitmap original, int radius)
        {
            Bitmap filtered = new Bitmap(original.Width, original.Height);

            for (int y = 0; y < original.Height; y++)
            {
                for (int x = 0; x < original.Width; x++)
                {
                    Color newColor = CalculateKuwaharaColor(original, x, y, radius);
                    filtered.SetPixel(x, y, newColor);
                }
            }

            return filtered;
        }
        private Color CalculateKuwaharaColor(Bitmap image, int x, int y, int radius)
    {
        int[] means = new int[4];
        int[] variances = new int[4];
        int[][] rValues = new int[4][];
        int[][] gValues = new int[4][];
        int[][] bValues = new int[4][];

        for (int i = 0; i < 4; i++)
        {
            rValues[i] = new int[(radius + 1) * (radius + 1)];
            gValues[i] = new int[(radius + 1) * (radius + 1)];
            bValues[i] = new int[(radius + 1) * (radius + 1)];
        }

        int[] counts = new int[4];
        int halfRadius = radius / 2;

        for (int j = -halfRadius; j <= halfRadius; j++)
        {
            for (int i = -halfRadius; i <= halfRadius; i++)
            {
                int pixelX = Clamp(x + i, 0, image.Width - 1);
                int pixelY = Clamp(y + j, 0, image.Height - 1);
                Color pixelColor = image.GetPixel(pixelX, pixelY);

                if (i <= 0 && j <= 0)
                {
                    rValues[0][counts[0]] = pixelColor.R;
                    gValues[0][counts[0]] = pixelColor.G;
                    bValues[0][counts[0]] = pixelColor.B;
                    counts[0]++;
                }
                if (i >= 0 && j <= 0)
                {
                    rValues[1][counts[1]] = pixelColor.R;
                    gValues[1][counts[1]] = pixelColor.G;
                    bValues[1][counts[1]] = pixelColor.B;
                    counts[1]++;
                }
                if (i <= 0 && j >= 0)
                {
                    rValues[2][counts[2]] = pixelColor.R;
                    gValues[2][counts[2]] = pixelColor.G;
                    bValues[2][counts[2]] = pixelColor.B;
                    counts[2]++;
                }
                if (i >= 0 && j >= 0)
                {
                    rValues[3][counts[3]] = pixelColor.R;
                    gValues[3][counts[3]] = pixelColor.G;
                    bValues[3][counts[3]] = pixelColor.B;
                    counts[3]++;
                }
            }
        }

        for (int i = 0; i < 4; i++)
        {
            means[i] = (int)(rValues[i].Average() + gValues[i].Average() + bValues[i].Average()) / 3;
            variances[i] = (int)(rValues[i].Variance() + gValues[i].Variance() + bValues[i].Variance()) / 3;
        }

        int minVarianceIndex = Array.IndexOf(variances, variances.Min());

        int avgR = (int)rValues[minVarianceIndex].Average();
        int avgG = (int)gValues[minVarianceIndex].Average();
        int avgB = (int)bValues[minVarianceIndex].Average();

        return Color.FromArgb(avgR, avgG, avgB);
    }

    public static int Clamp(int value, int min, int max)
    {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
}

public static class Extensions
{
    public static double Variance(this int[] values)
    {
        double avg = values.Average();
        return values.Average(v => Math.Pow(v - avg, 2));
    }
}

    }

