﻿namespace MMSproj1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.btnDownsample = new System.Windows.Forms.Button();
            this.btnCompress = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnBurkesDither = new System.Windows.Forms.Button();
            this.btnInvertFilter = new System.Windows.Forms.Button();
            this.btnKuwaharaFilter = new System.Windows.Forms.Button();
            this.btnKuwaharaFilter1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Location = new System.Drawing.Point(42, 317);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(123, 32);
            this.btnLoadImage.TabIndex = 0;
            this.btnLoadImage.Text = "Load Image";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDownsample
            // 
            this.btnDownsample.Location = new System.Drawing.Point(42, 355);
            this.btnDownsample.Name = "btnDownsample";
            this.btnDownsample.Size = new System.Drawing.Size(126, 32);
            this.btnDownsample.TabIndex = 1;
            this.btnDownsample.Text = "Downsample";
            this.btnDownsample.UseVisualStyleBackColor = true;
            this.btnDownsample.Click += new System.EventHandler(this.btnDownsample_Click);
            // 
            // btnCompress
            // 
            this.btnCompress.Location = new System.Drawing.Point(191, 317);
            this.btnCompress.Name = "btnCompress";
            this.btnCompress.Size = new System.Drawing.Size(123, 32);
            this.btnCompress.TabIndex = 2;
            this.btnCompress.Text = "Compress";
            this.btnCompress.UseVisualStyleBackColor = true;
            this.btnCompress.Click += new System.EventHandler(this.btnCompress_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(204, 40);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(382, 259);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // btnBurkesDither
            // 
            this.btnBurkesDither.Location = new System.Drawing.Point(191, 355);
            this.btnBurkesDither.Name = "btnBurkesDither";
            this.btnBurkesDither.Size = new System.Drawing.Size(123, 32);
            this.btnBurkesDither.TabIndex = 5;
            this.btnBurkesDither.Text = "BurkesDither";
            this.btnBurkesDither.UseVisualStyleBackColor = true;
            this.btnBurkesDither.Click += new System.EventHandler(this.btnBurkesDither_Click);
            // 
            // btnInvertFilter
            // 
            this.btnInvertFilter.Location = new System.Drawing.Point(338, 317);
            this.btnInvertFilter.Name = "btnInvertFilter";
            this.btnInvertFilter.Size = new System.Drawing.Size(110, 32);
            this.btnInvertFilter.TabIndex = 6;
            this.btnInvertFilter.Text = "Invert";
            this.btnInvertFilter.UseVisualStyleBackColor = true;
            this.btnInvertFilter.Click += new System.EventHandler(this.btnInvertFilter_Click);
            // 
            // btnKuwaharaFilter
            // 
            this.btnKuwaharaFilter.Location = new System.Drawing.Point(0, 0);
            this.btnKuwaharaFilter.Name = "btnKuwaharaFilter";
            this.btnKuwaharaFilter.Size = new System.Drawing.Size(75, 23);
            this.btnKuwaharaFilter.TabIndex = 0;
            // 
            // btnKuwaharaFilter1
            // 
            this.btnKuwaharaFilter1.Location = new System.Drawing.Point(338, 355);
            this.btnKuwaharaFilter1.Name = "btnKuwaharaFilter1";
            this.btnKuwaharaFilter1.Size = new System.Drawing.Size(110, 32);
            this.btnKuwaharaFilter1.TabIndex = 7;
            this.btnKuwaharaFilter1.Text = "Kuwahara";
            this.btnKuwaharaFilter1.UseVisualStyleBackColor = true;
            this.btnKuwaharaFilter1.Click += new System.EventHandler(this.btnKuwaharaFilter1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnKuwaharaFilter1);
            this.Controls.Add(this.btnKuwaharaFilter);
            this.Controls.Add(this.btnInvertFilter);
            this.Controls.Add(this.btnBurkesDither);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCompress);
            this.Controls.Add(this.btnDownsample);
            this.Controls.Add(this.btnLoadImage);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.Button btnDownsample;
        private System.Windows.Forms.Button btnCompress;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnBurkesDither;
        private System.Windows.Forms.Button btnInvertFilter;
        private System.Windows.Forms.Button btnKuwaharaFilter;
        private System.Windows.Forms.Button btnKuwaharaFilter1;
    }
}

